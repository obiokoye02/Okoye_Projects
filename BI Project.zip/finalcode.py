# -*- coding: utf-8 -*-
"""
Created on Mon Dec  4 21:23:10 2023

@author: micha
"""

import pandas as pd

# Updated file paths for the CSV files
cpi_path_csv = 'C:\\Users\\micha\\Downloads\\CPI_BY_CATEGORY.csv'
house_prices_path_csv = 'C:\\Users\\micha\\Downloads\\House Prices.csv'
median_income_path_csv = 'C:\\Users\\micha\\Downloads\\Median Household Income.csv'

# File path for the new CSV file
output_file_path_csv = 'C:\\Users\\micha\\Downloads\\project.csv'

# Reading the datasets
cpi_data = pd.read_csv(cpi_path_csv)
house_prices = pd.read_csv(house_prices_path_csv, skiprows=10)
median_income = pd.read_csv(median_income_path_csv, skiprows=10)

# Convert the date columns to datetime format
cpi_data['Month'] = pd.to_datetime(cpi_data['Month'], format='%b-%y', errors='coerce')
house_prices['observation_date'] = pd.to_datetime(house_prices['observation_date'], errors='coerce')
median_income['observation_date'] = pd.to_datetime(median_income['observation_date'], errors='coerce')

# Filtering the data to include only records from January 2007 onwards
start_date = '2007-01-01'
cpi_data = cpi_data[cpi_data['Month'] >= start_date]
house_prices = house_prices[house_prices['observation_date'] >= start_date]
median_income = median_income[median_income['observation_date'] >= start_date]

# Renaming the date column in all datasets to 'date'
cpi_data.rename(columns={'Month': 'date'}, inplace=True)
house_prices.rename(columns={'observation_date': 'date'}, inplace=True)
median_income.rename(columns={'observation_date': 'date'}, inplace=True)

# Merging the datasets on the 'date' column
# Merging CPI data with House Prices
merged_data = pd.merge(cpi_data, house_prices, on='date', how='outer')

# Merging the result with Median Household Income
merged_data = pd.merge(merged_data, median_income, on='date', how='outer')

# Renaming 'MSPUS' column to 'house price'
merged_data.rename(columns={'MSPUS': 'House Price'}, inplace=True)

# Adding year and quarter columns for grouping
merged_data['year'] = merged_data['date'].dt.year
merged_data['quarter'] = merged_data['date'].dt.to_period('Q')

# Replace forward filling with linear interpolation for house prices
merged_data.set_index('date', inplace=True)
merged_data['House Price'] = merged_data['House Price'].interpolate(method='linear')
merged_data.reset_index(inplace=True)

# For median income, assuming the same value for the entire year
merged_data['MEHOINUSA672N'] = merged_data.groupby('year')['MEHOINUSA672N'].transform('first')

# Converting annual median household income to monthly income
merged_data['MEHOINUSA672N'] = merged_data['MEHOINUSA672N'] / 12

# Renaming 'MEHOINUSA672N' column to 'monthly income'
merged_data.rename(columns={'MEHOINUSA672N': 'Median Monthly Income'}, inplace=True)

# Columns to be removed
columns_to_remove = [
    'Education and communication', 'Medical care services', 'Services less energy services',
    'Medical care commodities', 'New vehicles', 'Apparel',
    'Commodities less food and energy commodities', 'All items less food and energy',
    'Natural gas (piped)', 'Food away from home', 'Food at home', 'Shelter'
]

# Dropping the specified columns
merged_data.drop(columns=columns_to_remove, inplace=True, errors='ignore')

# Limiting the data to dates up to January 2023
end_date = pd.to_datetime('2023-01-01')
merged_data = merged_data[merged_data['date'] <= end_date]

# Renaming 'date' column to 'Date'
merged_data.rename(columns={'date': 'Date'}, inplace=True)

# Dropping the 'year' and 'quarter' columns as they are no longer needed
merged_data.drop(columns=['year', 'quarter'], inplace=True)

# Saving the merged_data DataFrame to a CSV file
merged_data.to_csv(output_file_path_csv, index=False)


import pandas as pd
import matplotlib.pyplot as plt

# Load your dataset
data = pd.read_csv("C:\\Users\\micha\\Downloads\\project.csv")

# Make sure 'Date' is in datetime format and CPI category columns are converted to floats
data['Date'] = pd.to_datetime(data['Date'])
cpi_category_columns = ['All items', 'Food', 'Energy', 'Gasoline (all types)', 'Electricity']
for col in cpi_category_columns:
    data[col] = data[col].str.rstrip('%').astype('float') / 100

# Visualization 1: Time Series Plot for House Prices and Median Monthly Income
plt.figure(figsize=(12, 6))
ax1 = data.plot(x='Date', y='House Price', label='House Price', color='blue', legend=True)
ax2 = data.plot(x='Date', y='Median Monthly Income', secondary_y=True, label='Median Monthly Income', ax=ax1, color='green', legend=True)
ax1.set_ylabel('House Price')
ax2.set_ylabel('Median Monthly Income')
plt.title('Time Series of House Prices and Median Monthly Income')
plt.grid(True)
plt.savefig("C:\\Users\\micha\\Downloads\\HousePrice_MedianIncome_Trend.png")
plt.show()

# Visualization 2: CPI Category Comparison Bar Chart
plt.figure(figsize=(12, 6))
cpi_comparison = data[cpi_category_columns].mean()
cpi_comparison.plot(kind='bar', color='purple')
plt.title('Average CPI Change by Category')
plt.ylabel('Average Change (%)')
plt.xticks(rotation=45)
plt.grid(True)
plt.savefig("C:\\Users\\micha\\Downloads\\CPI_Category_Comparison.png")
plt.show()

# Visualization 3: House Price to Income Ratio Over Time
data['Price_Income_Ratio'] = data['House Price'] / data['Median Monthly Income']
plt.figure(figsize=(12, 6))
plt.plot(data['Date'], data['Price_Income_Ratio'])
plt.title('House Price to Income Ratio Over Time')
plt.xlabel('Date')
plt.ylabel('Ratio')
plt.grid(True)
plt.savefig("C:\\Users\\micha\\Downloads\\HousePrice_Income_Ratio.png")
plt.show()